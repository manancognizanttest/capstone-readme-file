# ParaBank JMeter Load Test

## Purpose
Create and run a light, ethical JMeter load test against a verified read-only ParaBank endpoint.

## Recommended Endpoint
Use a read-only endpoint after verifying it in ParaBank docs:
`[INSERT VERIFIED READ-ONLY PARABANK ENDPOINT]`

Examples to verify before use:
- `/parabank/services/bank/customers/{customerId}/accounts`
- `/parabank/services/bank/accounts/{accountId}/transactions`

Avoid repeated create account, transfer, or database reset operations under load.

## CLI Example
```bash
jmeter -n -t ParaBank_LoadTest.jmx -l results.jtl -e -o html-report
```

## Screenshots to Capture
- Terminal showing CLI run completed: `../screenshots/jmeter_cli_run.png`
- HTML dashboard summary: `../screenshots/jmeter_html_dashboard.png`

## Summary Template
During the load test, I executed a light load against [INSERT VERIFIED READ-ONLY PARABANK ENDPOINT] using [INSERT THREAD COUNT] users and [INSERT LOOP COUNT] loops. The test completed with [INSERT ERROR COUNT] errors and an average response time of [INSERT AVG RESPONSE TIME]. Because this is a hosted demo application, the test was intentionally small and not intended to stress the server. Based on the results, the endpoint appeared [stable/unstable] for a small educational test workload.
